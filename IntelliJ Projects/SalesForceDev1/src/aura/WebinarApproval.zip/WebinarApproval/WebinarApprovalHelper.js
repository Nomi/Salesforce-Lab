/**
 * Created by nnoman on 08.07.2022.
 */

({
    doInit : function(component, helper) {
            // Apex function usage
            const getWebinars = component.get("c.getPendingWebinars");
            getWebinars.setParams({
                'queryLimit': component.get("v.webinarLimit")
            });
            getWebinars.setCallback(this, function(response) {
                if (response.getState() === 'SUCCESS') {
                    component.set("v.webinars", response.getReturnValue());
                }
                else {
                    console.log('Something went wrong');
                }
            });
            $A.enqueueAction(getWebinars);
            // End of apex function call
        },
    changeAppStat : function(component, helper,wid, status)
        {
                                    console.error('here')
            const updateWebinars = component.get("c.changeWebinarStatus");
            updateWebinars.setParams({
                'webinarId':wid,
                'status': status
            });
            console.error(wid)
            console.error(status)
            updateWebinars.setCallback(this, function(response) {
                    if (response.getState() === 'SUCCESS') {
                        //
                    }
                    else {
                        console.error('Something went wrong');
                    }
                });
            $A.enqueueAction(updateWebinars);
        }
});